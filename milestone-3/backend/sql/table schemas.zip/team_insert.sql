INSERT INTO Team (name, city, abbreviation, conference, wins, standing) VALUES
('Raptors', 'Toronto', 'TOR', 'East', 0, 0),
('Celtics', 'Boston', 'BOS', 'East', 0, 0);
