INSERT INTO Game (date, home_team, away_team, home_score, away_score) VALUES
('2024-11-16', 2, 1, 123, 126),
('2024-12-31', 2, 1, 125, 71),
('2025-01-15', 1, 2, 110, 97),
('2025-02-25', 1, 2, 101, 111);